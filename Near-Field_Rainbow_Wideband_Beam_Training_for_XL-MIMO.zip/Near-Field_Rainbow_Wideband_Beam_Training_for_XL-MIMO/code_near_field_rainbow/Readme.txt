
This simulation code package is mainly used to reproduce the results of the following paper [1]:

[1] M. Cui, L. Dai, Z. Wang, S. Zhou, and N. Ge, "Near-Field Rainbow: Wideband Beam Training for XL-MIMO," IEEE Trans. Wireless Commun., vol. 22, no. 6, pp. 3899-3912, Jun. 2023.
*********************************************************************************************************************************
If you use this simulation code package in any way, please cite the original paper [1] above. 
 
The author in charge of this simulation code pacakge is: Mingyao Cui (email: cmy20@mails.tsinghua.edu.cn).

Reference: We highly respect reproducible research, so we try to provide the simulation codes for our published papers 
( more information can be found at: 
http://oa.ee.tsinghua.edu.cn/dailinglong/publications/publications.html )

Please note that the MATLAB R2020b is used for this simulation code package,  
and there may be some imcompatibility problems among different MATLAB versions. 

Copyright reserved by the Broadband Communications and Signal Processing Laboratory (led by Dr. Linglong Dai), 
Beijing National Research Center for Information Science and Technology (BNRist), 
Department of Electronic Engineering, Tsinghua University, Beijing 100084, China. 

*********************************************************************************************************************************
Abstract of the paper: 

Wideband extremely large-scale multiple-inputmultiple-output (XL-MIMO) plays an important role in boosting
the data rate for 6G networks. Because of the huge bandwidth
and the large number of antennas, wideband XL-MIMO introduces a significant near-field beam split effect, where beams at
different frequencies are focused on different locations. This effect
results in a severe array gain loss, and existing works mainly
consider to compensate for this loss by utilizing time-delay (TD)
beamforming. This paper demonstrates that despite degrading
the array gain, the near-field beam split effect can also contribute
to the fast near-field beam training. Specifically, we first reveal
the controllable near-field beam split effect. This effect indicates
that TD beamforming can control the degree of the near-field
beam split effect, i.e., beams at different frequencies can flexibly
occupy the desired location range. Due to the similarity with
the dispersion of natural light caused by a prism, we also call
this effect as “near-field rainbow”. Then, by taking advantage
of the near-field rainbow, a fast wideband beam training scheme
is proposed to generate beams focusing on multiple locations at
multiple frequencies with the help of TD beamforming. Finally,
simulation results demonstrate that the proposed scheme is able
to realize efficient near-field beam training with low training
overheads.
*********************************************************************************************************************************
How to use this simulation code package?

1. Fig. 6(a) in this paper can be obtained by running "beam_angle.m".
2. Fig. 6(b) in this paper can be obtained by running "beam_distance.m".
3. Fig. 7 in this paper can be obtained by running "Rate_overhead.m".
4. Fig. 8 in this paper can be obtained by running "Rate_SNR.m".
5. Fig. 9 in this paper can be obtained by running "Rate_distance.m".
6. Fig. 10 in this paper can be obtained by running "Rate_direction.m".
*********************************************************************************************************************************
Enjoy the reproducible research!