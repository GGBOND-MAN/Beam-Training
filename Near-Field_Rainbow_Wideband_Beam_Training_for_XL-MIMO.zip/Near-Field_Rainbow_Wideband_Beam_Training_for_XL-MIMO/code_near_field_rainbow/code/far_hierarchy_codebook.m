function  [codebook, sin_theta_grids] = far_hierarchy_codebook(Nt, sin_theta_min, sin_theta_max, theta_num)



sin_theta_grids = linspace(sin_theta_min, sin_theta_max, theta_num);
beam_width = (sin_theta_max - sin_theta_min)/(theta_num - 1);

eps = 1e-12;
codebook = zeros(Nt, theta_num);
for i = 1:theta_num
    codebook(:, i) = WideBeamGenerate(sin_theta_grids(i), Nt, beam_width);
end


end

