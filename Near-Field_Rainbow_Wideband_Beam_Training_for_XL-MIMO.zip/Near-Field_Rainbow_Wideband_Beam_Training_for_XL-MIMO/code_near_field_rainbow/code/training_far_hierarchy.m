function [rate_far_hierarchy, sin_theta_best] = training_far_hierarchy(Nt, hc, sin_theta1_min, sin_theta1_max,theta_num, SNR_t, SNR_dB, Q, mode, M)

layer_num = length(theta_num);
%% ��ʼ������
sin_theta_min = zeros(1, layer_num);  sin_theta_max = zeros(1, layer_num);
sin_theta_min(1) = sin_theta1_min;  sin_theta_max(1) = sin_theta1_max;
beam_width = zeros(1, layer_num); 


for idx = 1:layer_num
   if idx == 1
      beam_width(idx) = (sin_theta_max(idx) - sin_theta_min(idx))/(theta_num(idx) - 1);
   else
      beam_width(idx) = beam_width(idx - 1)/(theta_num(idx) - 1);
   end
end

sin_theta_best = 0;
overhead = sum(theta_num);



if mode == 1
    idx = 0;
    rate_far_hierarchy = zeros(overhead, 1);
    for layer = 1:layer_num

        [far_codebook_layer, sin_theta_grids_layer] = far_hierarchy_codebook(Nt, sin_theta_min(layer), ...
                sin_theta_max(layer), theta_num(layer));
        for code = 1:theta_num(layer)  
            idx = idx + 1;
            wc_far_hierarchy = far_codebook_layer(:, code);
            array_gain = abs(hc * wc_far_hierarchy)^2;
            temp = log2(1 + SNR_t * array_gain);
            if idx == 1
               rate_far_hierarchy(idx) = temp;
               sin_theta_best = sin_theta_grids_layer(code);        
            else
                if temp > rate_far_hierarchy(idx - 1)
                   rate_far_hierarchy(idx) = temp;
                   sin_theta_best = sin_theta_grids_layer(code);
                else
                    rate_far_hierarchy(idx) = rate_far_hierarchy(idx - 1);
                end
            end
        end
        %% ������һ��Ĳ���
        if layer ~= layer_num
            sin_theta_min(layer + 1) = sin_theta_best - beam_width(layer)/2;
            sin_theta_max(layer + 1) = sin_theta_best + beam_width(layer)/2;
        end
    end
else
    %% �������ģʽ
    idx = 0;
    wc_best = zeros(Nt, 1);
    for layer = 1:layer_num
        array_gain_layer = zeros(theta_num(layer), 1);
        [far_codebook_layer, sin_theta_grids_layer] = far_hierarchy_codebook(Nt, sin_theta_min(layer), ...
                sin_theta_max(layer), theta_num(layer));
        for code = 1 : theta_num(layer) 
           idx = idx + 1;
           wc_far_hierarchy = far_codebook_layer(:, code);
           temp = awgn( repmat( hc * wc_far_hierarchy, [1, Q] ), SNR_dB + 10*log10(M) ); %Ƶ���˲�
           array_gain_layer(code) = abs(sum(temp)).^2;
        end
        %% ������һ��Ĳ���
        [~, code_max] = max(array_gain_layer);
        sin_theta_best = sin_theta_grids_layer(code_max);
        wc_best = far_codebook_layer(:, code_max); %���Ų���
        if layer ~= layer_num
            sin_theta_min(layer + 1) = sin_theta_best - beam_width(layer)/2;
            sin_theta_max(layer + 1) = sin_theta_best + beam_width(layer)/2;
        end
    end
    %% ��������
    rate_far_hierarchy = log2(1 + SNR_t * abs(hc * wc_best)^2);
end


end

