clear all;clc;
Nt = 256;
fc = 60e9;
c = 3e8;
B = 0.005*fc;
lambda_c = c/fc;
d = lambda_c / 2;
M = 512;
I = 200;
f = zeros(1, M);
for m= 1:M
    f(m)=fc+B/(M)*(m-1-(M-1)/2);
end
RD = 0.5*Nt*Nt*lambda_c;

%DFT      
D = 2 * Nt; %字典规模
row = (-(Nt - 1)/2:(Nt - 1)/2)' ;
col = -1 + 2/D : 2/D : 1 ;
DFT =  exp( 1j*  pi * row * col )/sqrt(Nt);
nn = -(Nt - 1)/2:1:(Nt-1)/2;

N_test = Nt * 5;


theta_c = 0;
r_min = 5;
r_max = 50;
r_list = linspace( r_min, r_max, N_test) * cos(theta_c).^2 ;
theta_list = linspace( theta_c, theta_c, N_test);
% r_list =  r0 * cos(theta_list).^2;


% channel
h = zeros(Nt, M, N_test);
for idx1 = 1:N_test
   for idx2 = 1:M
      h(:, idx2, idx1) = near_field_manifold( Nt, d, f(idx2), r_list(idx1), theta_list(idx1) ).';
   end
end


%% FDPP near-field beam 
sin_theta = sin(theta_c);
r0 = 20;
alpha = -2/d;

w_TTD = TTD_beam(Nt, B, fc, M, d, sin_theta, alpha);


%% TTD far-field beam 
w_TTD_far = TTD_beam(Nt, B, fc, M, d, sin_theta, 0);


%% beam pattern
beam_TTD = zeros(M, N_test);
beam_TTD_far = zeros(M, N_test);
for m = 1:M
    beam_TTD(m, :) =  abs(w_TTD(:, m).' * squeeze(h(:, m, :)));
    beam_TTD_far(m, :) =  abs(w_TTD_far(:, m).' * squeeze(h(:, m, :)));
end


% figure; hold on; grid on; box on;
% plot(r_list, beam_TTD(1, :), 'linewidth', 1) 
% for idx = 1 : I - 1
%     plot(r_list, beam_TTD(ceil(M/2 * idx / I), :), 'linewidth', 1) 
% end
% title('Near-field TTD beam')
% xlabel('angle')
% ylim([0,1])
% xlim([min(r_list), max(r_list)])

figure; hold on; grid on; box on;
plot(r_list, beam_TTD(ceil(M/2), :),'linewidth', 1) 
for idx = 1 : 5
    plot(r_list, beam_TTD(ceil(M/2) - 2 * idx, :),'linewidth', 1) 
end

% title('Near-field TTD beam')
xlabel('Distance (meters)', 'interpreter', 'latex', 'fontsize', 14)
ylabel('Array gain', 'interpreter', 'latex', 'fontsize', 14)
legend({'$f_{{\rm 1}}$','$f_{{\rm 2}}$','$f_{{\rm 3}}$','$f_{{\rm 4}}$','$f_{{\rm 5}}$','$f_{{\rm 6}}$'}, 'interpreter', 'latex','fontsize', 14);
% legend({'frequency 1', 'frequency 2', 'frequency 3', 'frequency 4', 'frequency 5', 'frequency 6'})
% ylim([0,1])
xlim([min(r_list), max(r_list)])



