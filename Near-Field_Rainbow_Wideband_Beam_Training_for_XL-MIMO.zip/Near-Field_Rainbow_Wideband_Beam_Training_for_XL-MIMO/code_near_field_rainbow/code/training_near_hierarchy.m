function [rate_near_hierarchy, x_best, y_best] =  training_near_hierarchy(Nt, d, fc, hc, x1_min, x1_max, y1_min, y1_max, x_num, y_num, SNR_t, SNR_dB, Q, mode, M)
layer_num = length(x_num); 
%% ��ʼ������
x_min = zeros(1, layer_num); x_max = zeros(1, layer_num);
y_min = zeros(1, layer_num); y_max = zeros(1, layer_num);
x_min(1) = x1_min; x_max(1) = x1_max;
y_min(1) = y1_min; y_max(1) = y1_max;

x_step = zeros(1, layer_num); y_step = zeros(1, layer_num);

for idx = 1:layer_num
   if idx == 1
      x_step(idx) = (x_max(idx) - x_min(idx))/(x_num(idx) - 1);
      y_step(idx) = (y_max(idx) - y_min(idx))/(y_num(idx) - 1);
   else
      x_step(idx) = x_step(idx - 1)/(x_num(idx) - 1);
      y_step(idx) = y_step(idx - 1)/(x_num(idx) - 1);
   end
end

x_best = 0;
y_best = 0;
overhead = sum(x_num.* y_num);

if mode == 1
    %% �������ģʽ
    rate_near_hierarchy = zeros(overhead, 1);
    idx = 0;
    for layer_id = 1:layer_num
        if idx > overhead
            break;
        end
        [near_codebook_layer_id, x_grids_layer_id, y_grids_layer_id] = ...
            near_hierarchy_codebook(Nt, d, fc, x_min(layer_id), x_max(layer_id),...
            x_num(layer_id), y_min(layer_id), y_max(layer_id), y_num(layer_id));
        near_codebook_layer_id = conj(near_codebook_layer_id);
        for code_id = 1 : x_num(layer_id) * y_num(layer_id)
           idx = idx + 1;
           y_label_id = mod( code_id - 1, y_num(layer_id) ) + 1;
           x_label_id = ceil( code_id/ x_num(layer_id));
           wc_near_hierarchy = near_codebook_layer_id(:, x_label_id, y_label_id);
           array_gain = abs(hc * wc_near_hierarchy)^2;
           temp = log2(1 + SNR_t * array_gain);
           if idx == 1 %��ʼ��
               rate_near_hierarchy(idx) = temp;
               x_best = x_grids_layer_id(x_label_id);
               y_best = y_grids_layer_id(y_label_id);
           else
               if temp > rate_near_hierarchy(idx - 1) %�ҵ����õ�һ��������
                    x_best = x_grids_layer_id(x_label_id);
                    y_best = y_grids_layer_id(y_label_id);
                    rate_near_hierarchy(idx) = temp;
               else
                    rate_near_hierarchy(idx) = rate_near_hierarchy(idx - 1);
               end
           end
        end
        %% ������һ��Ĳ���
        if layer_id ~= layer_num
            x_min(layer_id + 1) = x_best - x_step(layer_id)/2;
            x_max(layer_id + 1) = x_best + x_step(layer_id)/2;
            y_min(layer_id + 1) = y_best - y_step(layer_id)/2;
            y_max(layer_id + 1) = y_best + y_step(layer_id)/2;
        end
    end
else
    %% �������ģʽ
    array_gain = zeros(overhead, 1);
    idx = 0;
    wc_best = zeros(Nt, 1);
    for layer_id = 1:layer_num
        array_gain_layer = zeros(x_num(layer_id)* y_num(layer_id), 1);
        [near_codebook_layer_id, x_grids_layer_id, y_grids_layer_id] = ...
            near_hierarchy_codebook(Nt, d, fc, x_min(layer_id), x_max(layer_id),...
            x_num(layer_id), y_min(layer_id), y_max(layer_id), y_num(layer_id));
        near_codebook_layer_id = conj(near_codebook_layer_id);
        for code_id = 1 : x_num(layer_id) * y_num(layer_id)
           idx = idx + 1;
           y_label_id = mod( code_id - 1, y_num(layer_id) ) + 1;
           x_label_id = ceil( code_id/ x_num(layer_id));
           wc_near_hierarchy = near_codebook_layer_id(:, x_label_id, y_label_id);
           temp = awgn( repmat( hc * wc_near_hierarchy, [1, Q] ), SNR_dB + 10*log10(M) ); %Ƶ���˲�
           array_gain_layer(code_id) = abs(sum(temp)).^2;
        end
        %% ������һ��Ĳ���
        [~, code_id_max] = max(array_gain_layer);
        y_label_id_max = mod( code_id_max - 1, y_num(layer_id) ) + 1;
        x_label_id_max = ceil( code_id_max/ x_num(layer_id));
        x_best = x_grids_layer_id(x_label_id_max);
        y_best = y_grids_layer_id(y_label_id_max);
        wc_best = near_codebook_layer_id(:, x_label_id_max, y_label_id_max); %���Ų���
        if layer_id ~= layer_num
            x_min(layer_id + 1) = x_best - x_step(layer_id)/2;
            x_max(layer_id + 1) = x_best + x_step(layer_id)/2;
            y_min(layer_id + 1) = y_best - y_step(layer_id)/2;
            y_max(layer_id + 1) = y_best + y_step(layer_id)/2;
        end
    end
    %% ��������
    rate_near_hierarchy = log2(1 + SNR_t * abs(hc * wc_best)^2);
end
end

