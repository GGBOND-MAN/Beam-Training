clear all;clc;
Nt = 256;
fc = 60e9;
c = 3e8;
B = 0.05*fc;
lambda_c = c/fc;
d = lambda_c / 2;
M = 1024;
Q = 16;
N_iter = 100;
f = zeros(1, M);
topk = 1;
mode = 0;
for m= 1:M
    f(m)=fc+B/(M)*(m-1-(M-1)/2);
end
RD = 0.5*Nt*Nt*lambda_c;
%DFT     
s = 2;
D = s*Nt; %字典规模
row = (-(Nt - 1)/2:(Nt - 1)/2)' ;
col = -1 + 2/D : 2/D : 1 ;
DFT =  exp( 1j*  pi * row * col )/sqrt(Nt);




nn = -(Nt - 1)/2:1:(Nt-1)/2;



theta_min = - pi / 3;
theta_max = pi / 3;
theta_c = 0;
Rmin = 3;
Rmax = 30;


%% 远场宽带码字
[w_delay_far, sin_theta_far] = delay_angle_beam(Nt, theta_c, theta_max, theta_min, B, fc, M, d);
overhead1 = 1;

%% 近场宽带码字
rho_min = 3;
delta = 1.2;
[w_delay_near, sin_theta_near, alpha_near] = delay_polar_beam(Nt, theta_c, theta_max, theta_min, B, fc, M, d, rho_min, delta);
S = size(alpha_near, 1);
overhead2 = S;

%% 近场窄带码字
[w_phase_near, sin_theta_near_nb, r_near_nb] = PolarCode(Nt, s, d, lambda_c, delta, rho_min, theta_min, theta_max);
w_phase_near = conj(w_phase_near);

D2 = length(sin_theta_near_nb);
S2 = length(r_near_nb);
overhead3 = S2*D2;
%% 近场分层码字 分3层

x1_min = Rmin * cos(theta_min);
x1_max = Rmax;
y1_min = Rmax * sin(theta_min);
y1_max = Rmax * sin(theta_max);
x_num = [8,8];
y_num = [8,8];
overhead4 = sum(x_num.*y_num);

%% 远场分层码字 分3层
sin_theta1_min = sin(theta_min);
sin_theta1_max = sin(theta_max);
theta_num = [8, 8, 4];
overhead5 = sum(theta_num);

%% 参数
overhead_max = 256;



t0 = clock;
SNR_dB_list = linspace(-5, 15, 20);
SNR_list = 10.^(SNR_dB_list/10);
SNR_len = length(SNR_dB_list);


rate_far = zeros(length(SNR_list),N_iter);
rate_near = zeros(length(SNR_list),N_iter);
rate_near_nb = zeros(length(SNR_list),N_iter);
rate_opt = zeros(length(SNR_list),1);
rate_near_hierarchy = zeros(length(SNR_list), N_iter);
rate_far_hierarchy = zeros(length(SNR_list), N_iter);

parfor idx = 1:SNR_len
    SNR_dB = SNR_dB_list(idx);
    SNR = SNR_list(idx);
    fprintf('SNR_dB = %.4f[%d/%d] | run %.4f s\n', SNR_dB,  idx, SNR_len,  etime(clock, t0)); 
    for i_iter = 1:N_iter
        r = rand * (Rmax - Rmin) + Rmin;
        theta = rand * (theta_max - theta_min) + theta_min;
        [h, hc] = near_field_channel(Nt, d, fc, B, M, r, theta);
        %% 近场彩虹
        rate_near_iter = training_near_rainbow(Nt, B, fc, f, M, d, S, h, w_delay_near, theta_c, sin_theta_near, alpha_near, SNR, SNR_dB, Q, mode, topk);
        rate_near(idx, i_iter) = rate_near_iter;

        %% 远场彩虹
        rate_far_iter = training_far_rainbow(Nt, B, fc,f, M, d, h, w_delay_far,theta_c, sin_theta_far, SNR, SNR_dB, Q, mode, topk);
        rate_far(idx, i_iter) = rate_far_iter;

        %% 近场分级
        [rate_near_hierarchy_iter,~,~] = training_near_hierarchy(Nt, d, fc, hc, x1_min, x1_max, y1_min, y1_max, x_num, y_num, SNR, SNR_dB, Q, mode, M);
        rate_near_hierarchy(idx, i_iter) = rate_near_hierarchy_iter;
        
        %% 远场分级
        [rate_far_hierarchy_iter,~] = training_far_hierarchy(Nt, hc, sin_theta1_min, sin_theta1_max,theta_num, SNR, SNR_dB, Q, mode, M);
        rate_far_hierarchy(idx, i_iter) = rate_far_hierarchy_iter;

    
       %% 近场遍历
        rate_near_nb_iter = training_near_exhaustive(D2, S2,  hc, w_phase_near,SNR, SNR_dB, Q, mode, M, overhead_max);
        rate_near_nb(idx, i_iter) = rate_near_nb_iter;

       %% 理论上界
        wc_opt = exp(1j*phase(hc'))/sqrt(Nt);
        array_gain = abs(hc * wc_opt)^2;
        rate_opt(idx, i_iter) = log2(1 + SNR * array_gain);
    end
end
rate_far = mean(rate_far,2);
rate_near = mean(rate_near,2);
rate_near_nb = mean(rate_near_nb,2);
rate_opt = mean(rate_opt,2);
rate_near_hierarchy = mean(rate_near_hierarchy, 2);
rate_far_hierarchy = mean(rate_far_hierarchy, 2);


C = linspecer(6);
maker_num = 25;
figure; hold on; box on; grid on;
p1 = plot(SNR_dB_list(1:2:end), rate_opt(1:2:end), '--', 'color',C(1, :) , 'Linewidth', 1.6,'MarkerFaceColor','w');
p2 = Plot(SNR_dB_list(1:2:end), rate_near(1:2:end), maker_num, '-o','color', C(2, :), 'Linewidth', 1.6,'MarkerFaceColor','w');
p3 = Plot(SNR_dB_list(1:2:end), rate_near_nb(1:2:end), maker_num, '-s','color', C(3, :), 'Linewidth', 1.6,'MarkerFaceColor','w');
p4 = Plot(SNR_dB_list(1:2:end), rate_far(1:2:end), maker_num, '-d', 'color', C(4, :), 'Linewidth', 1.6,'MarkerFaceColor','w');
p5 = Plot(SNR_dB_list(1:2:end), rate_near_hierarchy(1:2:end) ,maker_num, '-^', 'color', C(5, :), 'Linewidth', 1.6,'MarkerFaceColor','w');
p6 = Plot(SNR_dB_list(1:2:end), rate_far_hierarchy(1:2:end), maker_num, '->', 'color', C(6, :), 'Linewidth', 1.6,'MarkerFaceColor','w');

xlabel('SNR (dB)', 'interpreter', 'latex', 'fontsize', 12)
ylabel('Average Rate (bit/s/Hz)', 'interpreter', 'latex', 'fontsize', 12)
legend([p1,p2,p4,p5,p6,p3],{'Perfect CSI',  'Proposed beam training', 'Far-field rainbow based beam training [15]',...
    'Near-field hierarchical beam training [18]', 'Far-field hierarchical beam training [17]', 'Exhaustive beam training'}, 'interpreter', 'latex', 'fontsize', 12);
xlim([min(SNR_dB_list(1:2:end)), max(SNR_dB_list(1:2:end))])
