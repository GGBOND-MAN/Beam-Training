function rate_near = training_near_rainbow(Nt, B, fc, f, M, d, S, h, w_delay_near, theta_c, sin_theta_near, alpha_near, SNR_t, SNR_dB, Q, mode, topk)
if mode == 1
    rate_near = zeros(S, 1);
    for idx = 1:S
            y_near = zeros(M,Q);
            for m = 1:M
               temp = awgn( repmat( h(m, :) * w_delay_near(:, idx, m), [1, Q] ), SNR_dB);
               y_near(m, :) =  temp;
            end
            y_near = abs( sum( y_near, 2 ) ).^2;

            % ������Ч�����ǶȺ;���
            [~, i] = max(y_near);

            theta_hat_near = asin( sin_theta_near + (sin(theta_c) - sin_theta_near) * fc / f(i) );
            r_hat_near = cos(theta_hat_near)^2 / 2 / alpha_near(idx);


            % ��������
            w_near = TTD_beam(Nt, B, fc, M, d, sin(theta_hat_near), alpha_near(idx));
            temp = 0;
            for m = 1:M
                temp = temp + log2(1 + SNR_t * abs(h(m, :) * w_near(:, m))^2 ) / M;
            end
            if idx == 1
                rate_near(idx) = temp;
            else
                rate_near(idx) = max([rate_near(idx-1); temp]);
            end         
    end
else
    %% ģʽ2
    y_near = zeros(Q, S, M);
    for s = 1:S
        for m = 1:M
           temp = awgn( repmat( h(m, :) * w_delay_near(:, s, m), [Q, 1, 1] ), SNR_dB);
           y_near(:, s, m) =  temp;
        end
    end
%     y_near = reshape( abs(sum( y_near, 1 )).^2, [S, M]) .* (f/fc).^2;
    y_near = reshape( abs(sum( y_near, 1 )).^2, [S, M]);
    % ����topk�����ǶȺ;���
    [v_near, ~] = sort(y_near(:), 'descend');
    rate_near_topk = zeros(1, topk);
    for topi = 1:topk
        [row, col] = find(v_near(topi) == y_near);  %col�����ز���ţ�row�Ǿ�����
    %     row
        theta_hat_near = asin( sin_theta_near + (sin(theta_c) - sin_theta_near) * fc / f(col) );
        alpha_hat_near = alpha_near(row);

       % ��������
        w_near = TTD_beam(Nt, B, fc, M, d, sin(theta_hat_near), alpha_hat_near);
        for m = 1:M
            rate_near_topk(topi) = rate_near_topk(topi) + log2(1 + SNR_t * abs(h(m, :) * w_near(:, m))^2 )/M;
        end
    end
    rate_near =  max(rate_near_topk);
end
end

