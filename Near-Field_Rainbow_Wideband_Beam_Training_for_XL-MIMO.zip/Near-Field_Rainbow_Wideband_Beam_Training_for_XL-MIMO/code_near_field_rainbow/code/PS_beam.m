function w = phase_polar_beam(Nt, f, d, r, theta)
%
c = 3e8;
k = 2 * pi * f / c;
nn = -(Nt - 1)/2:1:(Nt-1)/2;
rn = r - nn * d * sin(theta) + nn.^2 * d^2 * cos(theta)^2 / 2 / r;
% rn = sqrt(r^2 + (nn*d).^2 - 2*r*nn*d*sin(theta));
w = 1/sqrt(Nt)*exp( 1j * k * (rn - r) );
w = w.';

end

