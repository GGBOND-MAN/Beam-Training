%% generate the wide beam based on sub-array
function v = WideBeamGenerate(mu, Nt, w)
    Ns = floor((sqrt(1+2*w*Nt) - 1)/w);
    K = floor(Nt/Ns);
    while 2*K/Ns >= w
        Ns = Ns + 1;
        K = floor(Nt/Ns);
    end
    Ns = Ns - 1;
    K = floor(Nt/Ns);
    if Ns^4*(sin(pi/2/Ns))^2 < 8
        delta_eps = 2*acos(sqrt(2)/4*Ns^2*sin(pi/2/Ns));
    else
        delta_eps = (Ns-1)*pi/Ns+pi;
    end
    v = zeros(Nt, 1);
    for kidx = 1:K+1
        nuk = mu + (2*kidx - K - 1)/Ns;
        for nidx = 1:Ns
            if (kidx - 1)*Ns+nidx <= Nt
                v((kidx - 1)*Ns+nidx) = 1/sqrt(Nt)*exp(1j*pi*((kidx - 1)*Ns + nidx - 1)*nuk) ...
                    *exp(1j*kidx*delta_eps);
            end
        end
    end
end