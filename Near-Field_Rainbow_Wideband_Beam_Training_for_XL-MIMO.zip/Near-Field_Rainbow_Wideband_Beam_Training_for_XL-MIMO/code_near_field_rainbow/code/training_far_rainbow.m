function rate_far = training_far_rainbow(Nt, B, fc,f, M, d, h, w_delay_far,theta_c, sin_theta_far, SNR_t, SNR_dB, Q, mode, topk)
if mode == 1
    rate_far = 0;
    y_far = zeros(M,Q);
    for m = 1:M
       temp = awgn( repmat( h(m, :) * w_delay_far(:, m), [1, Q] ), SNR_dB);
       y_far(m, :) =  temp;
    end
    y_far = abs(sum( y_far, 2 )).^2;
    % ����topkԶ���Ƕ�
    [v_far, i] = max(  y_far );
    theta_hat_far = asin( sin_theta_far + (sin(theta_c) - sin_theta_far) * fc / f(i) );

    % ��������
    w_far = TTD_beam(Nt, B, fc, M, d, sin(theta_hat_far), 0);
    for m = 1:M
        rate_far = rate_far + log2(1 + SNR_t * abs(h(m, :) * w_far(:, m))^2 ) / M;
    end
else
    %% ģʽ2
    y_far = zeros(M,Q);
    for m = 1:M
      temp = awgn( repmat( h(m, :) * w_delay_far(:, m), [1, Q] ), SNR_dB);
       y_far(m, :) =  temp;
    end
    y_far = abs(sum( y_far, 2 )).^2;

    % ����topkԶ���Ƕ�
    [v_far, i_far] = sort(y_far, 'descend');
    rate_far_topk = zeros(1, topk);
    for topi = 1:topk
        theta_hat_far = asin( sin_theta_far + (sin(theta_c) - sin_theta_far) * fc / f(i_far(topi)) );

        % ��������
        w_far = TTD_beam(Nt, B, fc, M, d, sin(theta_hat_far), 0);
        for m = 1:M
            rate_far_topk(topi) = rate_far_topk(topi) + log2(1 + SNR_t * abs(h(m, :) * w_far(:, m))^2 )/M;
        end
    end
    rate_far = max(rate_far_topk);
end


