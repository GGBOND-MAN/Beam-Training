clear all;clc;
Nt = 256;
fc = 60e9;
c = 3e8;
B = 0.05*fc;
lambda_c = c/fc;
d = lambda_c / 2;
M = 1024;
Q = 16;
f = zeros(1, M);
N_iter = 50;
topk = 1;
for m= 1:M
    f(m)=fc+B/(M)*(m-1-(M-1)/2);
end
RD = 0.5*Nt*Nt*lambda_c;
Rmin = 3;
Rmax = 30;
user_theta_min = -pi / 3;
user_theta_max =  pi / 3;

%DFT     
s = 2;
D = s*Nt; %字典规模
row = (-(Nt - 1)/2:(Nt - 1)/2)' ;
col = -1 + 2/D : 2/D : 1 ;
DFT =  exp( 1j*  pi * row * col )/sqrt(Nt);
theta_max = pi/3;
theta_min = -pi/3;
theta_c = 0;

nn = -(Nt - 1)/2:1:(Nt-1)/2;



SNR_t = 10;
SNR_dB = 10;
SNR = 10^(SNR_dB/10);
mode = 1;
sigma2 = 1/SNR;

%% 远场宽带码字
[w_delay_far, sin_theta_far] = delay_angle_beam(Nt, theta_c, theta_max, theta_min, B, fc, M, d);
overhead1 = 1;

%% 近场宽带码字
rho_min = 3;
delta = 1.2;
[w_delay_near, sin_theta_near, alpha_near] = delay_polar_beam(Nt, theta_c, theta_max, theta_min, B, fc, M, d, rho_min, delta);
S = size(alpha_near, 1);
overhead2 = S;

%% 近场窄带码字
[w_phase_near, sin_theta_near_nb, r_near_nb] = PolarCode(Nt, s, d, lambda_c, delta, rho_min, theta_min, theta_max);
w_phase_near = conj(w_phase_near);

D2 = length(sin_theta_near_nb);
S2 = length(r_near_nb);
overhead3 = S2*D2;

%% 近场分层码字 分3层

x1_min = Rmin * cos(user_theta_min);
x1_max = Rmax;
y1_min = Rmax * sin(user_theta_min);
y1_max = Rmax * sin(user_theta_max);
x_num = [8,8];
y_num = [8,8];
overhead4 = sum(x_num.*y_num);

%% 远场分层码字 分3层
sin_theta1_min = sin(theta_min);
sin_theta1_max = sin(theta_max);
theta_num = [8, 8, 4];
overhead5 = sum(theta_num);

%% 合速率参数
overhead = 1: max([overhead1, overhead2, overhead3,overhead4, overhead5]);
overhead_max = length(overhead);
rate_far = zeros(length(overhead),N_iter);
rate_near = zeros(length(overhead),N_iter);
rate_near_nb = zeros(length(overhead),N_iter);
rate_opt = zeros(length(overhead),1);
rate_near_hierarchy = zeros(length(overhead), N_iter);
rate_far_hierarchy = zeros(length(overhead), N_iter);



for i_iter = 1:N_iter
    i_iter
    r = Rmin + rand * (Rmax - Rmin);
    theta = user_theta_min + rand * (user_theta_max - user_theta_min);
    [h, hc] = near_field_channel(Nt, d, fc, B, M, r, theta);
    
    %% 近场彩虹
    rate_near_iter = training_near_rainbow(Nt, B, fc, f, M, d, S, h, w_delay_near, theta_c, sin_theta_near, alpha_near, SNR_t, SNR_dB, Q, mode, topk);
    rate_near(1:S, i_iter) = rate_near_iter;
    rate_near(S+1:end, i_iter) = rate_near_iter(end);
    
    %% 远场彩虹
    rate_far_iter = training_far_rainbow(Nt, B, fc,f, M, d, h, w_delay_far,theta_c, sin_theta_far, SNR_t, SNR_dB, Q, mode, topk);
    rate_far(:, i_iter) = rate_far_iter;
    
    %% 近场遍历
    rate_near_nb_iter = training_near_exhaustive(D2, S2,  hc, w_phase_near,SNR_t, SNR_dB, Q, mode, M, overhead_max);
    rate_near_nb(1:S2*D2, i_iter) = rate_near_nb_iter;
    rate_near_nb(S2*D2+1:end, i_iter) = rate_near_nb_iter(end);
    
    %% 近场分级
    [rate_near_hierarchy_iter,~,~] = training_near_hierarchy(Nt, d, fc, hc, x1_min, x1_max, y1_min, y1_max, x_num, y_num, SNR_t, SNR_dB, Q, mode, M);
    rate_near_hierarchy(1:sum(x_num.*y_num), i_iter) = rate_near_hierarchy_iter;
    rate_near_hierarchy(sum(x_num.*y_num)+1:end, i_iter) = rate_near_hierarchy_iter(end);
    
    %% 远场分级
    [rate_far_hierarchy_iter,~] = training_far_hierarchy(Nt, hc, sin_theta1_min, sin_theta1_max,theta_num, SNR_t, SNR_dB, Q, mode, M);
    rate_far_hierarchy(1:sum(theta_num), i_iter) = rate_far_hierarchy_iter;
    rate_far_hierarchy(sum(theta_num)+1:end, i_iter) = rate_far_hierarchy_iter(end);
    
    %% 理论上界
    wc_opt = exp(1j*phase(hc'))/sqrt(Nt);
    array_gain = abs(hc * wc_opt)^2;
    rate_opt(:, i_iter) = log2(1 + SNR_t * array_gain);
end 
rate_far = mean(rate_far,2);
rate_near = mean(rate_near,2);
rate_near_nb = mean(rate_near_nb,2);
rate_opt = mean(rate_opt,2);
rate_near_hierarchy = mean(rate_near_hierarchy, 2);
rate_far_hierarchy = mean(rate_far_hierarchy, 2);


%% 
C = linspecer(6);
N1 = 25;
maker_num = 25;
figure; hold on; box on; grid on;
p1 = plot(overhead(1:N1), rate_opt(1:N1), '--', 'color',C(2, :) , 'Linewidth', 1.6,'MarkerFaceColor','w');
p2 = Plot(overhead(1:N1), rate_near(1:N1),maker_num, '-o','color', C(1, :), 'Linewidth', 1.6,'MarkerFaceColor','w');
p3 = Plot(overhead(1:N1), rate_near_nb(1:N1),maker_num, '-s','color', C(3, :), 'Linewidth', 1.6,'MarkerFaceColor','w');
p4 = Plot(overhead(1:N1), rate_far(1:N1),maker_num, '-d', 'color', C(4, :), 'Linewidth', 1.6,'MarkerFaceColor','w');
p5 = Plot(overhead(1:N1), rate_near_hierarchy(1:N1),maker_num, '-^', 'color', C(5, :), 'Linewidth', 1.6,'MarkerFaceColor','w');
p6 = Plot(overhead(1:N1), rate_far_hierarchy(1:N1),maker_num, '->', 'color', C(6, :), 'Linewidth', 1.6,'MarkerFaceColor','w');

ylim([0, max(rate_opt)*1.08])
xlim([1, N1])
xlabel('Training overhead', 'fontsize', 14, 'interpreter', 'latex')
ylabel('Average Rate (bit/s/Hz)', 'fontsize', 14, 'interpreter', 'latex')
legend([p1,p2,p4,p5,p6,p3],{'Perfect CSI',  'Proposed beam training', 'Far-field rainbow based training',...
    'Near-field hierarchical training', 'Far-field hierarchical training', 'Exhaustive training'}, 'interpreter', 'latex', 'fontsize', 12);

% N2 = length(overhead);
N2 = length(overhead);
maker_num = 25;
figure; hold on; box on; grid on;
p1 = plot(overhead(1:N2), rate_opt(1:N2), '--', 'color',C(2, :), 'Linewidth', 1.6,'MarkerFaceColor','w');
p2 = Plot(overhead(1:N2), rate_near(1:N2),maker_num, '-o','color', C(1, :), 'Linewidth', 1.6,'MarkerFaceColor','w');
p3 = Plot(overhead(1:N2), rate_near_nb(1:N2),maker_num, '-s','color', C(3, :), 'Linewidth', 1.6,'MarkerFaceColor','w');
p4 = Plot(overhead(1:N2), rate_far(1:N2),maker_num, '-d', 'color', C(4, :), 'Linewidth', 1.6,'MarkerFaceColor','w');
p5 = Plot(overhead(1:N2), rate_near_hierarchy(1:N2),maker_num, '-^', 'color', C(5, :), 'Linewidth', 1.6,'MarkerFaceColor','w');
p6 = Plot(overhead(1:N2), rate_far_hierarchy(1:N2),maker_num, '->', 'color', C(6, :), 'Linewidth', 1.6,'MarkerFaceColor','w');

xlabel('Training overhead', 'fontsize', 14, 'interpreter', 'latex')
ylabel('Average Rate (bit/s/Hz)', 'fontsize', 14, 'interpreter', 'latex')
legend([p1,p2,p4,p5,p6,p3],{'Perfect CSI',  'Proposed beam training', 'Far-field rainbow based training',...
    'Near-field hierarchical training', 'Far-field hierarchical training', 'Exhaustive training'}, 'interpreter', 'latex', 'fontsize', 12);
ylim([0, max(rate_opt)*1.08])
xlim([1, N2])
