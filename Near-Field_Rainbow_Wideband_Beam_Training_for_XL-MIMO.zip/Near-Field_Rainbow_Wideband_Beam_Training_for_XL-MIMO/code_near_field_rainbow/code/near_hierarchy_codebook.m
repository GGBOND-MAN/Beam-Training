function  [codebook, x_grids, y_grids] = near_hierarchy_codebook(Nt, d, f, x_min, x_max, x_num, y_min, y_max, y_num)
x_grids = linspace(x_min, x_max, x_num);
y_grids = linspace(y_min, y_max, y_num);

eps = 1e-12;
codebook = zeros(Nt, x_num, y_num);
for p = 1:x_num
   for  q = 1:y_num
      r = sqrt(x_grids(p)^2 +  y_grids(q)^2);
      theta = atan(y_grids(q) / (x_grids(p) + eps));
      codebook(:, p, q) = near_field_manifold(Nt, d, f, r, theta);
   end
end


end

