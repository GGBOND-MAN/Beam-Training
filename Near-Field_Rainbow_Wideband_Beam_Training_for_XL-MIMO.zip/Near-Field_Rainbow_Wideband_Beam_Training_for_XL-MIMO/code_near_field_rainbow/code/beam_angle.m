clear all;clc;
Nt = 256;
fc = 60e9;
c = 3e8;
B = 3e9;
lambda_c = c/fc;
d = lambda_c / 2;
M = 512;
f = zeros(1, M);
for m= 1:M
    f(m)=fc+B/(M)*(m-1-(M-1)/2);
end
RD = 0.5*Nt*Nt*lambda_c;

%DFT      
D = 2 * Nt; %字典规模
row = (-(Nt - 1)/2:(Nt - 1)/2)' ;
col = -1 + 2/D : 2/D : 1 ;
DFT =  exp( 1j*  pi * row * col )/sqrt(Nt);
nn = -(Nt - 1)/2:1:(Nt-1)/2;

N_test = Nt * 5;

r0 = 10;
theta_c = 0;
theta_min = - pi/16;
theta_max =   pi/16;
theta_min_test = - pi/12;
theta_max_test =   pi/12;
theta_list = linspace( theta_min_test, theta_max_test, N_test);
r_list =  r0 * cos(theta_list).^2;


% channel
h = zeros(Nt, M, N_test);
for idx1 = 1:N_test
   for idx2 = 1:M
      h(:, idx2, idx1) = fc/f(idx2) * near_field_manifold( Nt, d, f(idx2), r_list(idx1), theta_list(idx1) ).';
   end
end


%% FDPP near-field beam 
eta = B/fc;
fL = fc - B/2;
fH = fc + B/2;
p =  ceil( max([ ( fL/ B )* (sin(theta_max)-sin(theta_c)), ( fH / B )* (sin(theta_c)-sin(theta_min))])) ;
sin_theta = sin(theta_c) - 2 * p;
alpha = 1/2/r0;

w_TTD = TTD_beam(Nt, B, fc, M, d, sin_theta, alpha);

P = M;
p = f.^2 / sum(f.^2) * M; 
%% TTD far-field beam 
w_TTD_far = TTD_beam(Nt, B, fc, M, d, sin_theta, 0);


%% beam pattern
beam_TTD = zeros(M, N_test);
for m = 1:M
    beam_TTD(m, :) =  abs(sqrt(p(m))*w_TTD(:, m).' * squeeze(h(:, m, :)));
end


I = 15;
figure; hold on; grid on; box on;
plot(sin(theta_list), beam_TTD(1, :), 'linewidth', 1) 
for idx = 1 : I - 1
    plot(sin(theta_list), beam_TTD(ceil(M * idx / I), :), 'linewidth', 1) 
end
plot(sin(theta_list), beam_TTD(end, :), 'linewidth', 1) 
% plot(sin(theta_list),(sin(theta_list) + 1) , 'linewidth', 1) 
xlabel('Direction', 'interpreter', 'latex', 'fontsize', 14)
ylabel('Array gain', 'interpreter', 'latex', 'fontsize', 14)
ylim([0,1.1])
xlim([min(sin(theta_list)), max(sin(theta_list))])


