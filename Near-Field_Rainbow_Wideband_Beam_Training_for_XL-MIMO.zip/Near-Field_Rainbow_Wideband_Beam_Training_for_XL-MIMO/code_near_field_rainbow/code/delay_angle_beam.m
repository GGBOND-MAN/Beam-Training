function [w, sin_theta] = delay_angle_beam(Nt, theta_c, theta_max, theta_min, B, fc, M, d)
c = 3e8;
lambda_c = c/fc;
Tc = 1/fc;
f = zeros(1, M);
for m= 1:M
    f(m)=fc+B/(M)*(m-1-(M-1)/2);
end
k = 2 * pi * f / c;
nn = (-(Nt - 1)/2:1:(Nt-1)/2)';

%% phi1
eta = B/fc;
fL = fc - B/2;
fH = fc + B/2;
p =  ceil( max([ ( fL/ B )* (sin(theta_max)-sin(theta_c)), ( fH / B )* (sin(theta_c)-sin(theta_min))])) ;
sin_theta = sin(theta_c) - 2 * p;


%% delay
w = zeros(Nt,  M);

for m = 1:M
   w(:,  m) = 1/sqrt(Nt) * exp( - 1j * k(m) * (  nn * d * sin_theta ) );
end


end

